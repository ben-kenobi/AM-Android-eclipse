/** Automatically generated file. DO NOT MODIFY */
package com.yf.accountmanager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}