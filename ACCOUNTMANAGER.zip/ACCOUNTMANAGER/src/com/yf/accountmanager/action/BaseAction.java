package com.yf.accountmanager.action;


public interface BaseAction {
	void execute() throws Throwable;
}
