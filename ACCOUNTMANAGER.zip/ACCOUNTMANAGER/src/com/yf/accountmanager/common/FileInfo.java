package com.yf.accountmanager.common;

public class FileInfo {
	public long bytes;
	public int count;
}
